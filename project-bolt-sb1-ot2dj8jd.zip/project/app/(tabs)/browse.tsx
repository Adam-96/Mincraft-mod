import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { modCategories, minecraftMods } from '@/data/mods';
import { MinecraftMod, ModCategory } from '@/types/mod';
import CategoryCard from '@/components/CategoryCard';
import ModCard from '@/components/ModCard';
import { Grid3x3 as Grid3X3, Filter } from 'lucide-react-native';

export default function BrowseScreen() {
  const [favorites, setFavorites] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const handleCategoryPress = (category: ModCategory) => {
    setSelectedCategory(selectedCategory === category.name ? null : category.name);
  };

  const handleModPress = (mod: MinecraftMod) => {
    console.log('Pressed mod:', mod.name);
  };

  const handleFavorite = (mod: MinecraftMod) => {
    setFavorites(prev => 
      prev.includes(mod.id) 
        ? prev.filter(id => id !== mod.id)
        : [...prev, mod.id]
    );
  };

  const filteredMods = selectedCategory
    ? minecraftMods.filter(mod => mod.category === selectedCategory)
    : minecraftMods;

  const renderCategoryCard = ({ item }: { item: ModCategory }) => (
    <CategoryCard 
      category={item} 
      onPress={handleCategoryPress}
    />
  );

  const renderModCard = ({ item }: { item: MinecraftMod }) => (
    <ModCard 
      mod={item} 
      onPress={handleModPress}
      onFavorite={handleFavorite}
      isFavorite={favorites.includes(item.id)}
    />
  );

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#1A1A1A', '#2C3E50']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <Grid3X3 size={28} color="#16A085" />
          <Text style={styles.headerTitle}>Browse Mods</Text>
          <Text style={styles.headerSubtitle}>Explore by category</Text>
        </View>
      </LinearGradient>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Categories Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Filter size={20} color="#16A085" />
            <Text style={styles.sectionTitle}>Categories</Text>
            {selectedCategory && (
              <Text style={styles.activeFilter}>• {selectedCategory}</Text>
            )}
          </View>
          <FlatList
            data={modCategories}
            renderItem={renderCategoryCard}
            keyExtractor={(item) => item.id}
            numColumns={2}
            scrollEnabled={false}
            contentContainerStyle={styles.categoriesGrid}
          />
        </View>

        {/* Mods Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>
              {selectedCategory ? `${selectedCategory} Mods` : 'All Mods'}
            </Text>
            <Text style={styles.modCount}>({filteredMods.length})</Text>
          </View>
          <View style={styles.modsGrid}>
            {filteredMods.map((mod) => (
              <ModCard 
                key={mod.id}
                mod={mod} 
                onPress={handleModPress}
                onFavorite={handleFavorite}
                isFavorite={favorites.includes(mod.id)}
              />
            ))}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1A1A1A',
  },
  header: {
    paddingVertical: 24,
    paddingHorizontal: 16,
  },
  headerContent: {
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#fff',
    marginTop: 8,
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#BDC3C7',
  },
  content: {
    flex: 1,
  },
  section: {
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#fff',
    marginLeft: 8,
  },
  activeFilter: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#16A085',
    marginLeft: 8,
  },
  modCount: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#7F8C8D',
    marginLeft: 4,
  },
  categoriesGrid: {
    paddingBottom: 8,
  },
  modsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
});