import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { minecraftMods } from '@/data/mods';
import { MinecraftMod } from '@/types/mod';
import ModCard from '@/components/ModCard';
import { Heart, Trash2 } from 'lucide-react-native';

export default function FavoritesScreen() {
  const [favorites, setFavorites] = useState<string[]>(['1', '2', '5']); // Pre-populated with some favorites

  const handleModPress = (mod: MinecraftMod) => {
    console.log('Pressed mod:', mod.name);
  };

  const handleFavorite = (mod: MinecraftMod) => {
    setFavorites(prev => 
      prev.includes(mod.id) 
        ? prev.filter(id => id !== mod.id)
        : [...prev, mod.id]
    );
  };

  const clearAllFavorites = () => {
    setFavorites([]);
  };

  const favoriteMods = minecraftMods.filter(mod => favorites.includes(mod.id));

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#1A1A1A', '#2C3E50']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <Heart size={28} color="#E74C3C" fill="#E74C3C" />
          <Text style={styles.headerTitle}>My Favorites</Text>
          <Text style={styles.headerSubtitle}>Your saved mods</Text>
        </View>
      </LinearGradient>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {favoriteMods.length > 0 && (
          <View style={styles.favoritesHeader}>
            <Text style={styles.favoritesCount}>
              {favoriteMods.length} favorite mod{favoriteMods.length !== 1 ? 's' : ''}
            </Text>
            <TouchableOpacity 
              style={styles.clearButton}
              onPress={clearAllFavorites}
            >
              <Trash2 size={16} color="#E74C3C" />
              <Text style={styles.clearButtonText}>Clear All</Text>
            </TouchableOpacity>
          </View>
        )}

        {favoriteMods.length > 0 ? (
          <View style={styles.modsGrid}>
            {favoriteMods.map((mod) => (
              <ModCard 
                key={mod.id}
                mod={mod} 
                onPress={handleModPress}
                onFavorite={handleFavorite}
                isFavorite={true}
              />
            ))}
          </View>
        ) : (
          <View style={styles.emptyState}>
            <Heart size={64} color="#7F8C8D" />
            <Text style={styles.emptyTitle}>No favorites yet</Text>
            <Text style={styles.emptySubtitle}>
              Tap the heart icon on any mod to add it to your favorites
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1A1A1A',
  },
  header: {
    paddingVertical: 24,
    paddingHorizontal: 16,
  },
  headerContent: {
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#fff',
    marginTop: 8,
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#BDC3C7',
  },
  content: {
    flex: 1,
  },
  favoritesHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#2C3E50',
  },
  favoritesCount: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#BDC3C7',
  },
  clearButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: 'rgba(231, 76, 60, 0.1)',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(231, 76, 60, 0.3)',
  },
  clearButtonText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#E74C3C',
  },
  modsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
    paddingHorizontal: 32,
  },
  emptyTitle: {
    fontSize: 24,
    fontFamily: 'Inter-SemiBold',
    color: '#7F8C8D',
    marginTop: 24,
    marginBottom: 12,
  },
  emptySubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#7F8C8D',
    textAlign: 'center',
    lineHeight: 22,
  },
});