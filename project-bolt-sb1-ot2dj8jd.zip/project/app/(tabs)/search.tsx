import React, { useState, useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { minecraftMods, modCategories } from '@/data/mods';
import { MinecraftMod } from '@/types/mod';
import SearchBar from '@/components/SearchBar';
import ModCard from '@/components/ModCard';
import { Search, X, Filter } from 'lucide-react-native';

export default function SearchScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);

  const handleModPress = (mod: MinecraftMod) => {
    console.log('Pressed mod:', mod.name);
  };

  const handleFavorite = (mod: MinecraftMod) => {
    setFavorites(prev => 
      prev.includes(mod.id) 
        ? prev.filter(id => id !== mod.id)
        : [...prev, mod.id]
    );
  };

  const toggleCategory = (category: string) => {
    setSelectedCategories(prev =>
      prev.includes(category)
        ? prev.filter(cat => cat !== category)
        : [...prev, category]
    );
  };

  const clearFilters = () => {
    setSelectedCategories([]);
    setSearchQuery('');
  };

  const filteredMods = useMemo(() => {
    return minecraftMods.filter(mod => {
      const matchesSearch = searchQuery === '' || 
        mod.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        mod.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        mod.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
        mod.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesCategory = selectedCategories.length === 0 || 
        selectedCategories.includes(mod.category);

      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategories]);

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#1A1A1A', '#2C3E50']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <Search size={28} color="#16A085" />
          <Text style={styles.headerTitle}>Search Mods</Text>
          <Text style={styles.headerSubtitle}>Find your perfect mod</Text>
        </View>
      </LinearGradient>

      <View style={styles.searchContainer}>
        <SearchBar
          value={searchQuery}
          onChangeText={setSearchQuery}
          onFilterPress={() => setShowFilters(!showFilters)}
          placeholder="Search mods, authors, or tags..."
        />
      </View>

      {showFilters && (
        <View style={styles.filtersContainer}>
          <View style={styles.filtersHeader}>
            <Text style={styles.filtersTitle}>Filter by Category</Text>
            {(selectedCategories.length > 0 || searchQuery !== '') && (
              <TouchableOpacity onPress={clearFilters} style={styles.clearButton}>
                <X size={16} color="#E74C3C" />
                <Text style={styles.clearText}>Clear</Text>
              </TouchableOpacity>
            )}
          </View>
          <View style={styles.categoriesContainer}>
            {modCategories.map((category) => (
              <TouchableOpacity
                key={category.id}
                style={[
                  styles.categoryFilter,
                  {
                    backgroundColor: selectedCategories.includes(category.name) 
                      ? category.color 
                      : '#2C3E50'
                  }
                ]}
                onPress={() => toggleCategory(category.name)}
              >
                <Text style={styles.categoryFilterText}>{category.name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.resultsHeader}>
          <Text style={styles.resultsText}>
            {filteredMods.length} mod{filteredMods.length !== 1 ? 's' : ''} found
          </Text>
          {(selectedCategories.length > 0 || searchQuery !== '') && (
            <View style={styles.activeFilters}>
              {searchQuery !== '' && (
                <View style={styles.activeFilter}>
                  <Text style={styles.activeFilterText}>"{searchQuery}"</Text>
                </View>
              )}
              {selectedCategories.map((category) => (
                <View key={category} style={styles.activeFilter}>
                  <Text style={styles.activeFilterText}>{category}</Text>
                </View>
              ))}
            </View>
          )}
        </View>

        <View style={styles.modsGrid}>
          {filteredMods.map((mod) => (
            <ModCard 
              key={mod.id}
              mod={mod} 
              onPress={handleModPress}
              onFavorite={handleFavorite}
              isFavorite={favorites.includes(mod.id)}
            />
          ))}
        </View>

        {filteredMods.length === 0 && (
          <View style={styles.noResults}>
            <Search size={48} color="#7F8C8D" />
            <Text style={styles.noResultsText}>No mods found</Text>
            <Text style={styles.noResultsSubtext}>
              Try adjusting your search or filters
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1A1A1A',
  },
  header: {
    paddingVertical: 24,
    paddingHorizontal: 16,
  },
  headerContent: {
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#fff',
    marginTop: 8,
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#BDC3C7',
  },
  searchContainer: {
    paddingBottom: 8,
  },
  filtersContainer: {
    backgroundColor: '#2C3E50',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#34495E',
  },
  filtersHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  filtersTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#fff',
  },
  clearButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  clearText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#E74C3C',
  },
  categoriesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  categoryFilter: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  categoryFilterText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#fff',
  },
  content: {
    flex: 1,
  },
  resultsHeader: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#2C3E50',
  },
  resultsText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#BDC3C7',
    marginBottom: 8,
  },
  activeFilters: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
  },
  activeFilter: {
    backgroundColor: '#16A085',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
  },
  activeFilterText: {
    fontSize: 10,
    fontFamily: 'Inter-Medium',
    color: '#fff',
  },
  modsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  noResults: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 64,
  },
  noResultsText: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#7F8C8D',
    marginTop: 16,
    marginBottom: 8,
  },
  noResultsSubtext: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#7F8C8D',
    textAlign: 'center',
  },
});