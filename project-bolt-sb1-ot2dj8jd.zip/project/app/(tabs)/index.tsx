import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, FlatList, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { minecraftMods } from '@/data/mods';
import { MinecraftMod } from '@/types/mod';
import ModCard from '@/components/ModCard';
import { TrendingUp, Star, Crown, Zap } from 'lucide-react-native';

export default function HomeScreen() {
  const [favorites, setFavorites] = useState<string[]>([]);

  const featuredMods = minecraftMods.filter(mod => mod.featured);
  const popularMods = minecraftMods.filter(mod => mod.popular).slice(0, 6);
  const recentMods = minecraftMods.slice(0, 4);
  const jujutsuMod = minecraftMods.find(mod => mod.name === 'Jujutsu Awakening');

  const handleModPress = (mod: MinecraftMod) => {
    // TODO: Navigate to mod details
    console.log('Pressed mod:', mod.name);
  };

  const handleFavorite = (mod: MinecraftMod) => {
    setFavorites(prev => 
      prev.includes(mod.id) 
        ? prev.filter(id => id !== mod.id)
        : [...prev, mod.id]
    );
  };

  const renderModCard = ({ item }: { item: MinecraftMod }) => (
    <ModCard 
      mod={item} 
      onPress={handleModPress}
      onFavorite={handleFavorite}
      isFavorite={favorites.includes(item.id)}
    />
  );

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#1A1A1A', '#2C3E50']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <Text style={styles.headerTitle}>Minecraft Mods</Text>
          <Text style={styles.headerSubtitle}>Discover amazing mods for your world</Text>
        </View>
      </LinearGradient>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Jujutsu Awakening Highlight */}
        {jujutsuMod && (
          <View style={styles.specialSection}>
            <View style={styles.specialHeader}>
              <Zap size={24} color="#FF6B6B" />
              <Text style={styles.specialTitle}>Latest Addition</Text>
              <View style={styles.newBadge}>
                <Text style={styles.newBadgeText}>NEW</Text>
              </View>
            </View>
            <TouchableOpacity 
              style={styles.jujutsuCard}
              onPress={() => handleModPress(jujutsuMod)}
              activeOpacity={0.9}
            >
              <LinearGradient
                colors={['#FF6B6B', '#FF8E53']}
                style={styles.jujutsuGradient}
              >
                <Text style={styles.jujutsuTitle}>{jujutsuMod.name}</Text>
                <Text style={styles.jujutsuDescription} numberOfLines={2}>
                  {jujutsuMod.description}
                </Text>
                <View style={styles.jujutsuStats}>
                  <Text style={styles.jujutsuVersion}>v{jujutsuMod.version}</Text>
                  <View style={styles.jujutsuRating}>
                    <Star size={16} color="#FFD700" fill="#FFD700" />
                    <Text style={styles.jujutsuRatingText}>{jujutsuMod.rating}</Text>
                  </View>
                </View>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        )}

        {/* Featured Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Crown size={20} color="#F1C40F" />
            <Text style={styles.sectionTitle}>Featured Mods</Text>
          </View>
          <FlatList
            data={featuredMods}
            renderItem={renderModCard}
            keyExtractor={(item) => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.horizontalList}
          />
        </View>

        {/* Popular Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <TrendingUp size={20} color="#E74C3C" />
            <Text style={styles.sectionTitle}>Popular This Week</Text>
          </View>
          <View style={styles.grid}>
            {popularMods.map((mod) => (
              <ModCard 
                key={mod.id}
                mod={mod} 
                onPress={handleModPress}
                onFavorite={handleFavorite}
                isFavorite={favorites.includes(mod.id)}
              />
            ))}
          </View>
        </View>

        {/* Recent Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Star size={20} color="#16A085" />
            <Text style={styles.sectionTitle}>Recently Updated</Text>
          </View>
          <View style={styles.grid}>
            {recentMods.map((mod) => (
              <ModCard 
                key={mod.id}
                mod={mod} 
                onPress={handleModPress}
                onFavorite={handleFavorite}
                isFavorite={favorites.includes(mod.id)}
              />
            ))}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1A1A1A',
  },
  header: {
    paddingVertical: 24,
    paddingHorizontal: 16,
  },
  headerContent: {
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#fff',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#BDC3C7',
  },
  content: {
    flex: 1,
  },
  specialSection: {
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  specialHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  specialTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#fff',
    marginLeft: 8,
  },
  newBadge: {
    backgroundColor: '#FF6B6B',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 12,
    marginLeft: 8,
  },
  newBadgeText: {
    color: '#fff',
    fontSize: 10,
    fontFamily: 'Inter-Bold',
  },
  jujutsuCard: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#FF6B6B',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  jujutsuGradient: {
    padding: 20,
  },
  jujutsuTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#fff',
    marginBottom: 8,
  },
  jujutsuDescription: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: 'rgba(255, 255, 255, 0.9)',
    lineHeight: 22,
    marginBottom: 16,
  },
  jujutsuStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  jujutsuVersion: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#fff',
  },
  jujutsuRating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  jujutsuRatingText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#fff',
  },
  section: {
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#fff',
    marginLeft: 8,
  },
  horizontalList: {
    paddingRight: 16,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
});