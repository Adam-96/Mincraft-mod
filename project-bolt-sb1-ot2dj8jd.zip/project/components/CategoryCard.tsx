import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ModCategory } from '@/types/mod';
import * as Icons from 'lucide-react-native';

interface CategoryCardProps {
  category: ModCategory;
  onPress: (category: ModCategory) => void;
}

export default function CategoryCard({ category, onPress }: CategoryCardProps) {
  const IconComponent = (Icons as any)[category.icon] || Icons.Package;

  return (
    <TouchableOpacity 
      style={[styles.card, { backgroundColor: category.color }]} 
      onPress={() => onPress(category)}
      activeOpacity={0.8}
    >
      <View style={styles.iconContainer}>
        <IconComponent size={32} color="#fff" />
      </View>
      <Text style={styles.name}>{category.name}</Text>
      <Text style={styles.description} numberOfLines={2}>{category.description}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    margin: 6,
    minHeight: 120,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  iconContainer: {
    marginBottom: 8,
  },
  name: {
    color: '#fff',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    textAlign: 'center',
    marginBottom: 4,
  },
  description: {
    color: 'rgba(255, 255, 255, 0.9)',
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
    lineHeight: 16,
  },
});