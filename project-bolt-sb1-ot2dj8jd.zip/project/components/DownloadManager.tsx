import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, Linking } from 'react-native';
import { MinecraftMod } from '@/types/mod';
import { Download, ExternalLink, CheckCircle, AlertCircle, Loader } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';

interface DownloadManagerProps {
  mod: MinecraftMod;
  onDownloadComplete?: () => void;
}

type DownloadStatus = 'idle' | 'downloading' | 'completed' | 'error';

export default function DownloadManager({ mod, onDownloadComplete }: DownloadManagerProps) {
  const [downloadStatus, setDownloadStatus] = useState<DownloadStatus>('idle');
  const [progress, setProgress] = useState(0);

  const handleDirectDownload = async () => {
    setDownloadStatus('downloading');
    setProgress(0);

    // Simulate download progress
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          setDownloadStatus('completed');
          onDownloadComplete?.();
          return 100;
        }
        return prev + Math.random() * 15;
      });
    }, 200);

    // Simulate download completion after 3 seconds
    setTimeout(() => {
      clearInterval(progressInterval);
      setProgress(100);
      setDownloadStatus('completed');
      onDownloadComplete?.();
    }, 3000);
  };

  const handleMinecraftLaunch = () => {
    Alert.alert(
      'Launch Minecraft',
      'This will open Minecraft with the mod automatically installed. Make sure Minecraft is installed on your device.',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Launch', 
          onPress: () => {
            // Try to open Minecraft (this would work on mobile devices)
            Linking.openURL('minecraft://').catch(() => {
              Alert.alert('Error', 'Minecraft is not installed or cannot be opened.');
            });
          }
        }
      ]
    );
  };

  const handleManualInstall = () => {
    Alert.alert(
      'Manual Installation',
      `1. Download ${mod.name} v${mod.version}\n2. Open Minecraft\n3. Go to Mods folder\n4. Place the downloaded file\n5. Restart Minecraft\n\nFile size: ${mod.fileSize}`,
      [
        { text: 'Got it', style: 'default' },
        { text: 'Download File', onPress: handleDirectDownload }
      ]
    );
  };

  const getStatusIcon = () => {
    switch (downloadStatus) {
      case 'downloading':
        return <Loader size={20} color="#fff" />;
      case 'completed':
        return <CheckCircle size={20} color="#27AE60" />;
      case 'error':
        return <AlertCircle size={20} color="#E74C3C" />;
      default:
        return <Download size={20} color="#fff" />;
    }
  };

  const getStatusText = () => {
    switch (downloadStatus) {
      case 'downloading':
        return `Downloading... ${Math.round(progress)}%`;
      case 'completed':
        return 'Download Complete';
      case 'error':
        return 'Download Failed';
      default:
        return 'Quick Install';
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Transfer to Minecraft</Text>
      
      {/* Quick Install Button */}
      <TouchableOpacity 
        style={styles.quickInstallButton}
        onPress={downloadStatus === 'completed' ? handleMinecraftLaunch : handleDirectDownload}
        disabled={downloadStatus === 'downloading'}
      >
        <LinearGradient
          colors={downloadStatus === 'completed' ? ['#27AE60', '#2ECC71'] : ['#16A085', '#1ABC9C']}
          style={styles.quickInstallGradient}
        >
          <View style={styles.buttonContent}>
            {getStatusIcon()}
            <Text style={styles.quickInstallText}>
              {downloadStatus === 'completed' ? 'Launch Minecraft' : getStatusText()}
            </Text>
          </View>
          {downloadStatus === 'downloading' && (
            <View style={styles.progressContainer}>
              <View style={[styles.progressBar, { width: `${progress}%` }]} />
            </View>
          )}
        </LinearGradient>
      </TouchableOpacity>

      {/* Alternative Options */}
      <View style={styles.alternativeOptions}>
        <TouchableOpacity style={styles.alternativeButton} onPress={handleManualInstall}>
          <ExternalLink size={16} color="#16A085" />
          <Text style={styles.alternativeText}>Manual Install Guide</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.alternativeButton}
          onPress={() => Linking.openURL('https://www.minecraft.net/download')}
        >
          <Download size={16} color="#16A085" />
          <Text style={styles.alternativeText}>Get Minecraft</Text>
        </TouchableOpacity>
      </View>

      {/* Mod Info */}
      <View style={styles.modInfo}>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Version:</Text>
          <Text style={styles.infoValue}>{mod.version}</Text>
        </View>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Minecraft:</Text>
          <Text style={styles.infoValue}>{mod.minecraftVersion}</Text>
        </View>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>File Size:</Text>
          <Text style={styles.infoValue}>{mod.fileSize}</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#2C3E50',
    borderRadius: 16,
    padding: 20,
    margin: 16,
  },
  title: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#fff',
    marginBottom: 16,
    textAlign: 'center',
  },
  quickInstallButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
  },
  quickInstallGradient: {
    padding: 16,
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  quickInstallText: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#fff',
  },
  progressContainer: {
    height: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: 2,
    marginTop: 12,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    backgroundColor: '#fff',
    borderRadius: 2,
  },
  alternativeOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  alternativeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: 'rgba(22, 160, 133, 0.1)',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(22, 160, 133, 0.3)',
  },
  alternativeText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#16A085',
  },
  modInfo: {
    backgroundColor: 'rgba(0, 0, 0, 0.2)',
    borderRadius: 12,
    padding: 16,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  infoLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#BDC3C7',
  },
  infoValue: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#fff',
  },
});