import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import { MinecraftMod } from '@/types/mod';
import { Download, Star, Heart } from 'lucide-react-native';

interface ModCardProps {
  mod: MinecraftMod;
  onPress: (mod: MinecraftMod) => void;
  onFavorite?: (mod: MinecraftMod) => void;
  isFavorite?: boolean;
}

const { width } = Dimensions.get('window');
const cardWidth = (width - 48) / 2;

export default function ModCard({ mod, onPress, onFavorite, isFavorite = false }: ModCardProps) {
  const formatDownloads = (downloads: number): string => {
    if (downloads >= 1000000) {
      return `${(downloads / 1000000).toFixed(1)}M`;
    } else if (downloads >= 1000) {
      return `${(downloads / 1000).toFixed(1)}K`;
    }
    return downloads.toString();
  };

  return (
    <TouchableOpacity style={styles.card} onPress={() => onPress(mod)} activeOpacity={0.8}>
      <View style={styles.imageContainer}>
        <Image source={{ uri: mod.imageUrl }} style={styles.image} />
        {onFavorite && (
          <TouchableOpacity 
            style={styles.favoriteButton}
            onPress={() => onFavorite(mod)}
          >
            <Heart 
              size={20} 
              color={isFavorite ? '#E74C3C' : '#fff'} 
              fill={isFavorite ? '#E74C3C' : 'transparent'}
            />
          </TouchableOpacity>
        )}
        {mod.featured && (
          <View style={styles.featuredBadge}>
            <Text style={styles.featuredText}>Featured</Text>
          </View>
        )}
      </View>
      
      <View style={styles.content}>
        <Text style={styles.title} numberOfLines={1}>{mod.name}</Text>
        <Text style={styles.author} numberOfLines={1}>by {mod.author}</Text>
        <Text style={styles.description} numberOfLines={2}>{mod.description}</Text>
        
        <View style={styles.stats}>
          <View style={styles.statItem}>
            <Star size={12} color="#F1C40F" fill="#F1C40F" />
            <Text style={styles.statText}>{mod.rating}</Text>
          </View>
          <View style={styles.statItem}>
            <Download size={12} color="#7F8C8D" />
            <Text style={styles.statText}>{formatDownloads(mod.downloads)}</Text>
          </View>
        </View>
        
        <View style={styles.footer}>
          <View style={[styles.categoryBadge, { backgroundColor: getCategoryColor(mod.category) }]}>
            <Text style={styles.categoryText}>{mod.category}</Text>
          </View>
          <Text style={styles.version}>{mod.version}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

function getCategoryColor(category: string): string {
  const colors: { [key: string]: string } = {
    'Technology': '#3498DB',
    'Magic': '#9B59B6',
    'Adventure': '#E74C3C',
    'Building': '#F39C12',
    'Food': '#27AE60',
    'Decoration': '#E67E22',
    'Utility': '#34495E',
    'Exploration': '#16A085',
  };
  return colors[category] || '#7F8C8D';
}

const styles = StyleSheet.create({
  card: {
    width: cardWidth,
    backgroundColor: '#2C3E50',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  imageContainer: {
    position: 'relative',
  },
  image: {
    width: '100%',
    height: 120,
    resizeMode: 'cover',
  },
  favoriteButton: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderRadius: 15,
    padding: 5,
  },
  featuredBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: '#16A085',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  featuredText: {
    color: '#fff',
    fontSize: 10,
    fontFamily: 'Inter-SemiBold',
  },
  content: {
    padding: 12,
  },
  title: {
    color: '#fff',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 4,
  },
  author: {
    color: '#BDC3C7',
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    marginBottom: 6,
  },
  description: {
    color: '#ECF0F1',
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    lineHeight: 16,
    marginBottom: 8,
  },
  stats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statText: {
    color: '#BDC3C7',
    fontSize: 11,
    fontFamily: 'Inter-Medium',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  categoryBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
  },
  categoryText: {
    color: '#fff',
    fontSize: 10,
    fontFamily: 'Inter-Medium',
  },
  version: {
    color: '#7F8C8D',
    fontSize: 10,
    fontFamily: 'Inter-Regular',
  },
});