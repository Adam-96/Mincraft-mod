export interface MinecraftMod {
  id: string;
  name: string;
  description: string;
  category: ModCategory;
  author: string;
  version: string;
  minecraftVersion: string;
  downloads: number;
  rating: number;
  imageUrl: string;
  screenshots: string[];
  featured: boolean;
  popular: boolean;
  installationGuide: string;
  tags: string[];
  fileSize: string;
  lastUpdated: string;
}

export type ModCategory = 
  | 'Technology'
  | 'Magic'
  | 'Adventure'
  | 'Building'
  | 'Food'
  | 'Decoration'
  | 'Utility'
  | 'Exploration';

export interface ModCategory {
  id: string;
  name: ModCategory;
  description: string;
  icon: string;
  color: string;
}